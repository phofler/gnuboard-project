<?php
$sub_menu = "800150";
include_once('../../common.php');
define('G5_IS_ADMIN', true);
include_once(G5_ADMIN_PATH . '/admin.lib.php');

$g5['title'] = "상단 메뉴 스킨 관리";
include_once(G5_ADMIN_PATH . '/admin.head.php');

$plugin_path = G5_PLUGIN_PATH . '/top_menu_manager';
$skins_path = $plugin_path . '/skins';
$setting_file = $plugin_path . '/setting.php';

// Save logic
if (isset($_POST['skin_name']) && $_POST['skin_name']) {
    $skin_name = preg_replace('/[^a-z0-9_]/i', '', $_POST['skin_name']); // Sanitize
    $content = "<?php\nif (!defined('_GNUBOARD_')) exit;\n\$top_menu_skin = '{$skin_name}';\n?>";
    file_put_contents($setting_file, $content);
    alert('스킨이 적용되었습니다.', './admin.php');
}

// Load current setting
$top_menu_skin = 'basic_light'; // default
if (file_exists($setting_file)) {
    include($setting_file);
}

// Get skin list
$skins = array();
$dir = dir($skins_path);
while ($entry = $dir->read()) {
    if ($entry == '.' || $entry == '..')
        continue;
    if (is_dir($skins_path . '/' . $entry)) {
        $skins[] = $entry;
    }
}
$dir->close();
?>

<div class="local_desc01 local_desc">
    <p>상단 메인 메뉴(GNB)의 디자인 스킨을 선택할 수 있습니다.</p>
</div>

<form name="fskin" method="post" action="./admin.php">
    <div class="tbl_head01 tbl_wrap">
        <table>
            <caption><?php echo $g5['title']; ?> 목록</caption>
            <colgroup>
                <col width="150">
                <col>
                <col width="100">
            </colgroup>
            <thead>
                <tr>
                    <th>스킨명</th>
                    <th>미리보기</th>
                    <th>선택</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($skins as $skin) {
                    $is_active = ($skin == $top_menu_skin);
                    $preview_img = G5_PLUGIN_URL . '/top_menu_manager/skins/' . $skin . '/preview.png';
                    if (!file_exists($skins_path . '/' . $skin . '/preview.png')) {
                        // Generate a dummy preview if not exists (or just show text)
                        $preview_img = '';
                    }
                    ?>
                    <tr class="<?php echo $is_active ? 'bg2' : ''; ?>">
                        <td class="td_category">
                            <?php echo $skin; ?>
                            <?php if ($is_active)
                                echo '<br><strong style="color:red">[사용중]</strong>'; ?>
                        </td>
                        <td style="padding:10px; text-align:center;">
                            <?php if ($preview_img) { ?>
                                <img src="<?php echo $preview_img; ?>" style="max-width:300px; border:1px solid #ddd;">
                            <?php } else { ?>
                                <div
                                    style="width:300px; height:50px; line-height:50px; background:#f0f0f0; margin:0 auto; border:1px solid #ddd; color:#888;">
                                    No Preview</div>
                            <?php } ?>
                        </td>
                        <td class="td_mng">
                            <?php if (!$is_active) { ?>
                                <button type="submit" name="skin_name" value="<?php echo $skin; ?>" class="btn btn_03">이 스킨
                                    적용</button>
                            <?php } else { ?>
                                <button type="button" class="btn btn_02" disabled>적용중</button>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</form>

<?php
include_once(G5_ADMIN_PATH . '/admin.tail.php');
?>