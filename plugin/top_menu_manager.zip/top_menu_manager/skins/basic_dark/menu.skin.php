<?php
include(dirname(__FILE__) . '/../basic_light/menu.skin.php');
?>