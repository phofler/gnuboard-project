<?php
if (!defined('_GNUBOARD_'))
    exit;

$menu_datas = get_menu_db(0, true);
?>

<!-- Modern Header -->
<header class="modern-header">
    <a href="<?php echo G5_URL ?>" class="modern-logo">
        <?php echo $config['cf_title']; ?> <span>.</span>
    </a>

    <nav class="modern-gnb">
        <ul class="modern-gnb-ul">
            <?php foreach ($menu_datas as $row) {
                if (empty($row))
                    continue;
                ?>
                <li class="modern-gnb-li">
                    <a href="<?php echo $row['me_link']; ?>" target="_<?php echo $row['me_target']; ?>"
                        class="modern-gnb-a"><?php echo $row['me_name'] ?></a>
                    <?php
                    if (isset($row['sub']) && $row['sub']) {
                        ?>
                        <div class="modern-sub-menu">
                            <ul class="modern-sub-ul">
                                <?php foreach ((array) $row['sub'] as $row2) {
                                    if (empty($row2))
                                        continue;
                                    ?>
                                    <li class="modern-sub-li"><a href="<?php echo $row2['me_link']; ?>"
                                            target="_<?php echo $row2['me_target']; ?>"><?php echo $row2['me_name'] ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                    <?php } ?>
                </li>
            <?php } ?>
        </ul>
    </nav>

    <div class="modern-util">
        <?php if ($is_member) { ?>
            <a href="<?php echo G5_BBS_URL ?>/logout.php" class="util-btn">LOGOUT</a>
            <?php if ($is_admin) { ?>
                <a href="<?php echo G5_ADMIN_URL ?>" class="util-btn">ADMIN</a>
            <?php } else { ?>
                <a href="<?php echo G5_BBS_URL ?>/member_confirm.php?url=register_form.php" class="util-btn">MY PAGE</a>
            <?php } ?>
        <?php } else { ?>
            <a href="<?php echo G5_BBS_URL ?>/login.php" class="util-btn">LOGIN</a>
            <a href="<?php echo G5_BBS_URL ?>/register.php" class="util-btn">JOIN</a>
        <?php } ?>

        <button class="util-menu-btn modern-mobile-toggle"><i class="fa fa-bars"></i></button>
    </div>
</header>

<!-- Mobile Menu (Hidden by default, toggled by JS) -->
<div id="modern_mobile_menu" style="display:none;">
    <div class="modern-mobile-bg"></div>
    <div class="modern-mobile-content">
        <button class="modern-mobile-close"><i class="fa fa-times"></i></button>
        <ul class="modern-mobile-ul">
            <?php foreach ($menu_datas as $row) { ?>
                <li>
                    <a href="<?php echo $row['me_link']; ?>"
                        target="_<?php echo $row['me_target']; ?>"><?php echo $row['me_name'] ?></a>
                    <?php if (isset($row['sub']) && $row['sub']) { ?>
                        <ul>
                            <?php foreach ((array) $row['sub'] as $row2) { ?>
                                <li><a href="<?php echo $row2['me_link']; ?>"
                                        target="_<?php echo $row2['me_target']; ?>"><?php echo $row2['me_name'] ?></a></li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </li>
            <?php } ?>
        </ul>
    </div>
</div>

<script>
    $(document).ready(function () {
        $(".modern-mobile-toggle").click(function () {
            $("#modern_mobile_menu").fadeIn();
            $(".modern-mobile-content").addClass("active");
        });
        $(".modern-mobile-close, .modern-mobile-bg").click(function () {
            $("#modern_mobile_menu").fadeOut();
            $(".modern-mobile-content").removeClass("active");
        });
    });
</script>